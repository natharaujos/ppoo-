public class Logica {
    
    public static void main(String [] args) {

        Calculadora calculadora = new Calculadora();

        calculadora.exibirJanela();
    }
}
