public interface Interface {
    
    double contribuicao();
}
