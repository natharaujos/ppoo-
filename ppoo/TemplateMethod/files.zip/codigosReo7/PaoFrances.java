public class PaoFrances extends Sanduiche {
    public PaoFrances(String nome) {
        setNome(nome);
    }
    
    @Override
    public double getPreco() {
        return 1.5;
    }
}