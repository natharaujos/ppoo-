public interface TipoDeCarro {

    public double calculaNota(double valorDiaria, int numeroDias);
}